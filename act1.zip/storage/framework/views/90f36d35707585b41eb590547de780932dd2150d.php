<html>
	<body>
		<h1><center>HELLO WORLD!</center></h1>
	</body>
</html><?php /**PATH C:\xampp\htdocs\act1\resources\views/index.blade.php ENDPATH**/ ?>